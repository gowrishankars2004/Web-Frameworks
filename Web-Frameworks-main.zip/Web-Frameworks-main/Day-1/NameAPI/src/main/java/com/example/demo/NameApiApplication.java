package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NameApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(NameApiApplication.class, args);
	}

}
